data:extend({

  {
    type = "recipe",
    name = "radar-red",
	enabled = false,
	energy_required = 5,
    ingredients =
    {
      {"radar", 1},
      {"iron-gear-wheel", 20},
      {"steel-plate", 10},
      {"productivity-module", 1}
    },
    result = "radar-red",
    requester_paste_multiplier = 4
  },
  {
    type = "recipe",
    name = "radar-green",
	enabled = false,
	energy_required = 5,
    ingredients =
    {
      {"radar", 1},
      {"electronic-circuit", 25},
      {"effectivity-module", 1}
    },
    result = "radar-green",
    requester_paste_multiplier = 4
  },
  {
    type = "recipe",
    name = "radar-blue",
	enabled = false,
	energy_required = 5,
    ingredients =
    {
      {"radar", 1},
      {"advanced-circuit", 20},
      {"speed-module", 1}
    },
    result = "radar-blue",
    requester_paste_multiplier = 4
  }
  
  })