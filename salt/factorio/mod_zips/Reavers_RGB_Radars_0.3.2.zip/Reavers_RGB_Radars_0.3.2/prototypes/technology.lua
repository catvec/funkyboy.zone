data:extend({

{
    type = "technology",
    name = "radar-red-tech",
    icon = "__Reavers_RGB_Radars__/graphics/technology_icon_radar_red.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "radar-red"
      }
    },
	prerequisites = {"military-2", "productivity-module"},
    unit =
    {
      count = 100,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"military-science-pack", 1}
	  },
      time = 30
    },
	order = "z-r-a"
  },
{
    type = "technology",
    name = "radar-green-tech",
    icon = "__Reavers_RGB_Radars__/graphics/technology_icon_radar_green.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "radar-green"
      }
    },
	prerequisites = {"effectivity-module"},
    unit =
    {
      count = 100,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"science-pack-3", 1}
	  },
      time = 30
    },
	order = "z-r-a"
  },
{
    type = "technology",
    name = "radar-blue-tech",
    icon = "__Reavers_RGB_Radars__/graphics/technology_icon_radar_blue.png",
	icon_size = 128,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "radar-blue"
      }
    },
	prerequisites = {"speed-module", "advanced-material-processing-2"},
    unit =
    {
      count = 100,
      ingredients = {
	  {"science-pack-1", 1},
	  {"science-pack-2", 1},
	  {"production-science-pack", 1}
	  },
      time = 30
    },
	order = "z-r-a"
  }
  
  })