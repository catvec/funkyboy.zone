data:extend({
  {
	type = "item",
	name = "radar-red",
	icon = "__Reavers_RGB_Radars__/graphics/item_icon_radar_red.png",
	icon_size = 32,
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = "g[radar]-a[radar]",
	place_result = "radar-red",
	stack_size = 20
  },
  {
	type = "item",
	name = "radar-green",
	icon = "__Reavers_RGB_Radars__/graphics/item_icon_radar_green.png",
	icon_size = 32,
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = "h[radar]-a[radar]",
	place_result = "radar-green",
	stack_size = 20
  },
  {
	type = "item",
	name = "radar-blue",
	icon = "__Reavers_RGB_Radars__/graphics/item_icon_radar_blue.png",
	icon_size = 32,
	flags = {"goes-to-quickbar"},
	subgroup = "defensive-structure",
	order = "i[radar]-a[radar]",
	place_result = "radar-blue",
	stack_size = 20
  }
})
